/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.Vault
 *  net.milkbowl.vault.economy.Economy
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.Sign
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.FileConfigurationOptions
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Vehicle
 *  org.bukkit.event.Event
 *  org.bukkit.event.Event$Result
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockFromToEvent
 *  org.bukkit.event.block.BlockPhysicsEvent
 *  org.bukkit.event.block.BlockPistonExtendEvent
 *  org.bukkit.event.block.BlockPistonRetractEvent
 *  org.bukkit.event.block.SignChangeEvent
 *  org.bukkit.event.entity.EntityExplodeEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerPortalEvent
 *  org.bukkit.event.server.PluginDisableEvent
 *  org.bukkit.event.server.PluginEnableEvent
 *  org.bukkit.event.vehicle.VehicleMoveEvent
 *  org.bukkit.event.world.WorldLoadEvent
 *  org.bukkit.event.world.WorldUnloadEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginDescriptionFile
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.plugin.messaging.PluginMessageListener
 *  org.bukkit.plugin.messaging.PluginMessageListenerRegistration
 *  org.bukkit.scheduler.BukkitScheduler
 */
package com.RkCraft.Stargate;

import com.RkCraft.Stargate.Blox;
import com.RkCraft.Stargate.BloxPopulator;
import com.RkCraft.Stargate.Gate;
import com.RkCraft.Stargate.LangLoader;
import com.RkCraft.Stargate.Portal;
import com.RkCraft.Stargate.RelativeBlockVector;
import com.RkCraft.Stargate.Updater;
import com.RkCraft.Stargate.event.StargateAccessEvent;
import com.RkCraft.Stargate.event.StargateDestroyEvent;
import com.RkCraft.Stargate.iConomyHandler;
import com.RkCraft.Stargate.pmListener;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.milkbowl.vault.Vault;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.FileConfigurationOptions;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.event.vehicle.VehicleMoveEvent;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.event.world.WorldUnloadEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.plugin.messaging.PluginMessageListenerRegistration;
import org.bukkit.scheduler.BukkitScheduler;

public class Stargate
extends JavaPlugin {
    public static Logger log;
    private FileConfiguration newConfig;
    private PluginManager pm;
    public static Server server;
    public static Stargate stargate;
    private static LangLoader lang;
    private static String portalFolder;
    private static String gateFolder;
    private static String langFolder;
    private static String defNetwork;
    private static boolean destroyExplosion;
    public static int maxGates;
    private static String langName;
    private static final int activeTime = 10;
    private static final int openTime = 10;
    public static boolean destMemory;
    public static boolean handleVehicles;
    public static boolean sortLists;
    public static boolean protectEntrance;
    public static boolean enableBungee;
    public static ChatColor signColor;
    public static boolean ignoreEntrance;
    public static boolean debug;
    public static boolean permDebug;
    public static ConcurrentLinkedQueue<Portal> openList;
    public static ConcurrentLinkedQueue<Portal> activeList;
    public static Queue<BloxPopulator> blockPopulatorQueue;
    public static Map<String, String> bungeeQueue;

    public void onDisable() {
        Portal.closeAllGates();
        Portal.clearGates();
        this.getServer().getScheduler().cancelTasks((Plugin)this);
    }

    public void onEnable() {
        PluginDescriptionFile pdfFile = this.getDescription();
        this.pm = this.getServer().getPluginManager();
        this.newConfig = this.getConfig();
        log = Logger.getLogger("Minecraft");
        server = this.getServer();
        stargate = this;
        if (this.getConfig().getBoolean("CheckUpdates")) {
            this.CheckUpdate();
        }
        portalFolder = this.getDataFolder().getPath().replaceAll("\\\\", "/") + "/portals/";
        gateFolder = this.getDataFolder().getPath().replaceAll("\\\\", "/") + "/gates/";
        langFolder = this.getDataFolder().getPath().replaceAll("\\\\", "/") + "/lang/";
        log.log(Level.INFO, "{0} v.{1} is enabled.", new Object[]{pdfFile.getName(), pdfFile.getVersion()});
        this.pm.registerEvents((Listener)new pListener(), (Plugin)this);
        this.pm.registerEvents((Listener)new bListener(), (Plugin)this);
        this.pm.registerEvents((Listener)new vListener(), (Plugin)this);
        this.pm.registerEvents((Listener)new eListener(), (Plugin)this);
        this.pm.registerEvents((Listener)new wListener(), (Plugin)this);
        this.pm.registerEvents((Listener)new sListener(), (Plugin)this);
        this.loadConfig();
        if (enableBungee) {
            Bukkit.getMessenger().registerOutgoingPluginChannel((Plugin)this, "BungeeCord");
            Bukkit.getMessenger().registerIncomingPluginChannel((Plugin)this, "BungeeCord", (PluginMessageListener)new pmListener());
        }
        lang = new LangLoader(langFolder, langName);
        this.migrate();
        this.reloadGates();
        if (iConomyHandler.setupeConomy(this.pm) && iConomyHandler.economy != null) {
            log.log(Level.INFO, "[Stargate] Vault v{0} found", iConomyHandler.vault.getDescription().getVersion());
        }
        this.getServer().getScheduler().scheduleSyncRepeatingTask((Plugin)this, (Runnable)new SGThread(), 0, 100);
        this.getServer().getScheduler().scheduleSyncRepeatingTask((Plugin)this, (Runnable)new BlockPopulatorThread(), 0, 1);
    }

    public void loadConfig() {
        this.reloadConfig();
        this.newConfig = this.getConfig();
        this.newConfig.options().copyDefaults(true);
        portalFolder = this.newConfig.getString("portal-folder");
        gateFolder = this.newConfig.getString("gate-folder");
        defNetwork = this.newConfig.getString("default-gate-network").trim();
        destroyExplosion = this.newConfig.getBoolean("destroyexplosion");
        maxGates = this.newConfig.getInt("maxgates");
        langName = this.newConfig.getString("lang");
        destMemory = this.newConfig.getBoolean("destMemory");
        ignoreEntrance = this.newConfig.getBoolean("ignoreEntrance");
        handleVehicles = this.newConfig.getBoolean("handleVehicles");
        sortLists = this.newConfig.getBoolean("sortLists");
        protectEntrance = this.newConfig.getBoolean("protectEntrance");
        enableBungee = this.newConfig.getBoolean("enableBungee");
        String sc = this.newConfig.getString("signColor");
        try {
            signColor = ChatColor.valueOf((String)sc.toUpperCase());
        }
        catch (Exception ignore) {
            log.warning("[Stargate] You have specified an invalid color in your config.yml. Defaulting to BLACK");
            signColor = ChatColor.BLACK;
        }
        debug = this.newConfig.getBoolean("debug");
        permDebug = this.newConfig.getBoolean("permdebug");
        iConomyHandler.useiConomy = this.newConfig.getBoolean("useiconomy");
        iConomyHandler.createCost = this.newConfig.getInt("createcost");
        iConomyHandler.destroyCost = this.newConfig.getInt("destroycost");
        iConomyHandler.useCost = this.newConfig.getInt("usecost");
        iConomyHandler.toOwner = this.newConfig.getBoolean("toowner");
        iConomyHandler.chargeFreeDestination = this.newConfig.getBoolean("chargefreedestination");
        iConomyHandler.freeGatesGreen = this.newConfig.getBoolean("freegatesgreen");
        this.saveConfig();
    }

    public void reloadGates() {
        for (Portal p : openList) {
            p.close(true);
        }
        Gate.loadGates(gateFolder);
        if (Gate.getGateByName("nethergate.gate") == null || Gate.getGateByName("nethergate.gate").getExit() == null) {
            Gate.populateDefaults(gateFolder);
        }
        log.log(Level.INFO, "[Stargate] Loaded {0} gate layouts", Gate.getGateCount());
        for (World world : this.getServer().getWorlds()) {
            Portal.loadAllGates(world);
        }
    }

    private void migrate() {
        File newFile;
        File oldDir;
        File newPortalDir = new File(portalFolder);
        if (!newPortalDir.exists()) {
            newPortalDir.mkdirs();
        }
        if (!(newFile = new File(portalFolder, ((World)this.getServer().getWorlds().get(0)).getName() + ".db")).exists()) {
            newFile.getParentFile().mkdirs();
            File oldishFile = new File("plugins/Stargate/stargate.db");
            if (oldishFile.exists()) {
                log.info("[Stargate] Migrating existing stargate.db");
                oldishFile.renameTo(newFile);
            }
        }
        if ((oldDir = new File("stargates")).exists()) {
            File newDir = new File(gateFolder);
            if (!newDir.exists()) {
                newDir.mkdirs();
            }
            for (File file : oldDir.listFiles(new Gate.StargateFilenameFilter())) {
                log.log(Level.INFO, "[Stargate] Migrating existing gate {0}", file.getName());
                file.renameTo(new File(gateFolder, file.getName()));
            }
        }
    }

    public static void debug(String rout, String msg) {
        if (debug) {
            log.log(Level.INFO, "[Stargate::{0}] {1}", new Object[]{rout, msg});
        } else {
            log.log(Level.FINEST, "[Stargate::{0}] {1}", new Object[]{rout, msg});
        }
    }

    public static void sendMessage(CommandSender player, String message) {
        Stargate.sendMessage(player, message, true);
    }

    public static void sendMessage(CommandSender player, String message, boolean error) {
        if (message.isEmpty()) {
            return;
        }
        message = message.replaceAll("(&([a-f0-9]))", "\u00a7$2");
        if (error) {
            player.sendMessage((Object)ChatColor.RED + Stargate.getString("prefix") + (Object)ChatColor.WHITE + message);
        } else {
            player.sendMessage((Object)ChatColor.GREEN + Stargate.getString("prefix") + (Object)ChatColor.WHITE + message);
        }
    }

    public static void setLine(Sign sign, int index, String text) {
        sign.setLine(index, (Object)signColor + text);
    }

    public static String getSaveLocation() {
        return portalFolder;
    }

    public static String getGateFolder() {
        return gateFolder;
    }

    public static String getDefaultNetwork() {
        return defNetwork;
    }

    public static String getString(String name) {
        return lang.getString(name);
    }

    public static void openPortal(Player player, Portal portal) {
        Portal destination = portal.getDestination();
        if (portal.isAlwaysOn()) {
            return;
        }
        if (portal.isRandom()) {
            return;
        }
        if (destination == null || destination == portal) {
            Stargate.sendMessage((CommandSender)player, Stargate.getString("invalidMsg"));
            return;
        }
        if (portal.isOpen()) {
            if (portal.getActivePlayer() == player) {
                portal.close(false);
            }
            return;
        }
        if (!portal.isFixed() && portal.isActive() && portal.getActivePlayer() != player) {
            Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
            return;
        }
        if (portal.isPrivate() && !Stargate.canPrivate(player, portal)) {
            Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
            return;
        }
        if (destination.isOpen() && !destination.isAlwaysOn()) {
            Stargate.sendMessage((CommandSender)player, Stargate.getString("blockMsg"));
            return;
        }
        portal.open(player, false);
    }

    public static boolean hasPerm(Player player, String perm) {
        if (permDebug) {
            Stargate.debug("hasPerm::SuperPerm(" + player.getName() + ")", perm + " => " + player.hasPermission(perm));
        }
        return player.hasPermission(perm);
    }

    public static boolean hasPermDeep(Player player, String perm) {
        if (!player.isPermissionSet(perm)) {
            if (permDebug) {
                Stargate.debug("hasPermDeep::SuperPerm", perm + " => true");
            }
            return true;
        }
        if (permDebug) {
            Stargate.debug("hasPermDeep::SuperPerms", perm + " => " + player.hasPermission(perm));
        }
        return player.hasPermission(perm);
    }

    public static boolean canAccessWorld(Player player, String world) {
        if (Stargate.hasPerm(player, "stargate.use") || Stargate.hasPerm(player, "stargate.world")) {
            return Stargate.hasPermDeep(player, "stargate.world." + world);
        }
        return Stargate.hasPerm(player, "stargate.world." + world);
    }

    public static boolean canAccessNetwork(Player player, String network) {
        if (Stargate.hasPerm(player, "stargate.use") || Stargate.hasPerm(player, "stargate.network")) {
            return Stargate.hasPermDeep(player, "stargate.network." + network);
        }
        if (Stargate.hasPerm(player, "stargate.network." + network)) {
            return true;
        }
        String playerName = player.getName();
        if (playerName.length() > 11) {
            playerName = playerName.substring(0, 11);
        }
        return network.equals(playerName) && Stargate.hasPerm(player, "stargate.create.personal");
    }

    public static boolean canAccessServer(Player player, String server) {
        if (Stargate.hasPerm(player, "stargate.use") || Stargate.hasPerm(player, "stargate.servers")) {
            return Stargate.hasPermDeep(player, "stargate.server." + server);
        }
        return Stargate.hasPerm(player, "stargate.server." + server);
    }

    public static boolean canAccessPortal(Player player, Portal portal, boolean deny) {
        StargateAccessEvent event = new StargateAccessEvent(player, portal, deny);
        server.getPluginManager().callEvent((Event)event);
        return !event.getDeny();
    }

    public static boolean isFree(Player player, Portal src, Portal dest) {
        if (src.isFree()) {
            return true;
        }
        if (Stargate.hasPerm(player, "stargate.free") || Stargate.hasPerm(player, "stargate.free.use")) {
            return true;
        }
        return dest != null && !iConomyHandler.chargeFreeDestination && dest.isFree();
    }

    public static boolean canSee(Player player, Portal portal) {
        if (!portal.isHidden()) {
            return true;
        }
        if (Stargate.hasPerm(player, "stargate.admin") || Stargate.hasPerm(player, "stargate.admin.hidden")) {
            return true;
        }
        return portal.getOwner().equalsIgnoreCase(player.getName());
    }

    public static boolean canPrivate(Player player, Portal portal) {
        if (portal.getOwner().equalsIgnoreCase(player.getName())) {
            return true;
        }
        return Stargate.hasPerm(player, "stargate.admin") || Stargate.hasPerm(player, "stargate.admin.private");
    }

    public static boolean canOption(Player player, String option) {
        if (Stargate.hasPerm(player, "stargate.option")) {
            return true;
        }
        return Stargate.hasPerm(player, "stargate.option." + option);
    }

    public static boolean canCreate(Player player, String network) {
        if (Stargate.hasPerm(player, "stargate.create")) {
            return true;
        }
        if (Stargate.hasPerm(player, "stargate.create.network")) {
            return Stargate.hasPermDeep(player, "stargate.create.network." + network);
        }
        return Stargate.hasPerm(player, "stargate.create.network." + network);
    }

    public static boolean canCreatePersonal(Player player) {
        if (Stargate.hasPerm(player, "stargate.create")) {
            return true;
        }
        return Stargate.hasPerm(player, "stargate.create.personal");
    }

    public static boolean canCreateGate(Player player, String gate) {
        if (Stargate.hasPerm(player, "stargate.create")) {
            return true;
        }
        if (Stargate.hasPerm(player, "stargate.create.gate")) {
            return Stargate.hasPermDeep(player, "stargate.create.gate." + gate);
        }
        return Stargate.hasPerm(player, "stargate.create.gate." + gate);
    }

    public static boolean canDestroy(Player player, Portal portal) {
        String network = portal.getNetwork();
        if (Stargate.hasPerm(player, "stargate.destroy")) {
            return true;
        }
        if (Stargate.hasPerm(player, "stargate.destroy.network")) {
            return Stargate.hasPermDeep(player, "stargate.destroy.network." + network);
        }
        if (Stargate.hasPerm(player, "stargate.destroy.network." + network)) {
            return true;
        }
        return player.getName().equalsIgnoreCase(portal.getOwner()) && Stargate.hasPerm(player, "stargate.destroy.personal");
    }

    public static boolean chargePlayer(Player player, String target, int cost) {
        if (cost == 0) {
            return true;
        }
        if (!iConomyHandler.useiConomy()) {
            return true;
        }
        return iConomyHandler.chargePlayer(player.getName(), target, cost);
    }

    public static int getUseCost(Player player, Portal src, Portal dest) {
        if (!iConomyHandler.useiConomy()) {
            return 0;
        }
        if (src.isFree()) {
            return 0;
        }
        if (dest != null && !iConomyHandler.chargeFreeDestination && dest.isFree()) {
            return 0;
        }
        if (src.getGate().getToOwner().booleanValue() && src.getOwner().equalsIgnoreCase(player.getName())) {
            return 0;
        }
        if (Stargate.hasPerm(player, "stargate.free") || Stargate.hasPerm(player, "stargate.free.use")) {
            return 0;
        }
        return src.getGate().getUseCost();
    }

    public static int getCreateCost(Player player, Gate gate) {
        if (!iConomyHandler.useiConomy()) {
            return 0;
        }
        if (Stargate.hasPerm(player, "stargate.free") || Stargate.hasPerm(player, "stargate.free.create")) {
            return 0;
        }
        return gate.getCreateCost();
    }

    public static int getDestroyCost(Player player, Gate gate) {
        if (!iConomyHandler.useiConomy()) {
            return 0;
        }
        if (Stargate.hasPerm(player, "stargate.free") || Stargate.hasPerm(player, "stargate.free.destroy")) {
            return 0;
        }
        return gate.getDestroyCost();
    }

    private Plugin checkPlugin(String p) {
        Plugin plugin = this.pm.getPlugin(p);
        return this.checkPlugin(plugin);
    }

    private Plugin checkPlugin(Plugin plugin) {
        if (plugin != null && plugin.isEnabled()) {
            log.log(Level.INFO, "[Stargate] Found {0} (v{1})", new Object[]{plugin.getDescription().getName(), plugin.getDescription().getVersion()});
            return plugin;
        }
        return null;
    }

    public static String replaceVars(String format, String[] search, String[] replace) {
        if (search.length != replace.length) {
            return "";
        }
        for (int i = 0; i < search.length; ++i) {
            format = format.replace(search[i], replace[i]);
        }
        return format;
    }

    public void CheckUpdate() {
        Updater updater = new Updater((Plugin)this, 98673, this.getFile(), Updater.UpdateType.DEFAULT, false);
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName();
        if (cmd.equalsIgnoreCase("sg")) {
            Player p;
            if (args.length != 1) {
                return false;
            }
            if (args[0].equalsIgnoreCase("about")) {
                sender.sendMessage("Stargate Plugin created by Drakia");
                if (!lang.getString("author").isEmpty()) {
                    sender.sendMessage("Language created by " + lang.getString("author"));
                }
                return true;
            }
            if (sender instanceof Player && !Stargate.hasPerm(p = (Player)sender, "stargate.admin") && !Stargate.hasPerm(p, "stargate.admin.reload")) {
                Stargate.sendMessage(sender, "Permission Denied");
                return true;
            }
            if (args[0].equalsIgnoreCase("reload")) {
                for (Portal p2 : activeList) {
                    p2.deactivate();
                }
                for (Portal p2 : openList) {
                    p2.close(true);
                }
                activeList.clear();
                openList.clear();
                Portal.clearGates();
                Gate.clearGates();
                boolean oldEnableBungee = enableBungee;
                this.loadConfig();
                this.reloadGates();
                lang.setLang(langName);
                lang.reload();
                if (iConomyHandler.useiConomy && iConomyHandler.economy == null && iConomyHandler.setupeConomy(this.pm) && iConomyHandler.economy != null) {
                    log.log(Level.INFO, "[Stargate] Vault v{0} found", iConomyHandler.vault.getDescription().getVersion());
                }
                if (!iConomyHandler.useiConomy) {
                    iConomyHandler.vault = null;
                    iConomyHandler.economy = null;
                }
                if (oldEnableBungee != enableBungee) {
                    if (enableBungee) {
                        Bukkit.getMessenger().registerOutgoingPluginChannel((Plugin)this, "BungeeCord");
                        Bukkit.getMessenger().registerIncomingPluginChannel((Plugin)this, "BungeeCord", (PluginMessageListener)new pmListener());
                    } else {
                        Bukkit.getMessenger().unregisterIncomingPluginChannel((Plugin)this, "BungeeCord");
                        Bukkit.getMessenger().unregisterOutgoingPluginChannel((Plugin)this, "BungeeCord");
                    }
                }
                Stargate.sendMessage(sender, "Stargate reloaded");
                return true;
            }
            return false;
        }
        return false;
    }

    static {
        defNetwork = "central";
        destroyExplosion = false;
        maxGates = 0;
        langName = "en";
        destMemory = false;
        handleVehicles = true;
        sortLists = false;
        protectEntrance = false;
        enableBungee = true;
        ignoreEntrance = false;
        debug = false;
        permDebug = false;
        openList = new ConcurrentLinkedQueue();
        activeList = new ConcurrentLinkedQueue();
        blockPopulatorQueue = new LinkedList<BloxPopulator>();
        bungeeQueue = new HashMap<String, String>();
    }

    private class SGThread
    implements Runnable {
        private SGThread() {
        }

        @Override
        public void run() {
            Portal p;
            long time = System.currentTimeMillis() / 1000;
            Iterator<Portal> iter = Stargate.openList.iterator();
            while (iter.hasNext()) {
                p = iter.next();
                if (p.isAlwaysOn() || !p.isOpen() || time <= p.getOpenTime() + 10) continue;
                p.close(false);
                iter.remove();
            }
            iter = Stargate.activeList.iterator();
            while (iter.hasNext()) {
                p = iter.next();
                if (!p.isActive() || time <= p.getOpenTime() + 10) continue;
                p.deactivate();
                iter.remove();
            }
        }
    }

    private class BlockPopulatorThread
    implements Runnable {
        private BlockPopulatorThread() {
        }

        @Override
        public void run() {
            long sTime = System.nanoTime();
            while (System.nanoTime() - sTime < 50000000) {
                BloxPopulator b = Stargate.blockPopulatorQueue.poll();
                if (b == null) {
                    return;
                }
                b.getBlox().getBlock().setTypeId(b.getMat());
                b.getBlox().getBlock().setData(b.getData());
            }
        }
    }

    private class sListener
    implements Listener {
        private sListener() {
        }

        @EventHandler
        public void onPluginEnable(PluginEnableEvent event) {
            if (iConomyHandler.setupVault(event.getPlugin())) {
                Stargate.log.log(Level.INFO, "[Stargate] Vault v{0} found", iConomyHandler.vault.getDescription().getVersion());
            }
        }

        @EventHandler
        public void onPluginDisable(PluginDisableEvent event) {
            if (iConomyHandler.checkLost(event.getPlugin())) {
                Stargate.log.info("[Stargate] Vault plugin lost.");
            }
        }
    }

    private class eListener
    implements Listener {
        private eListener() {
        }

        @EventHandler
        public void onEntityExplode(EntityExplodeEvent event) {
            if (event.isCancelled()) {
                return;
            }
            for (Block b : event.blockList()) {
                Portal portal = Portal.getByBlock(b);
                if (portal == null) continue;
                if (destroyExplosion) {
                    portal.unregister(true);
                    continue;
                }
                Stargate.blockPopulatorQueue.add(new BloxPopulator(new Blox(b), b.getTypeId(), b.getData()));
                event.setCancelled(true);
            }
        }
    }

    private class wListener
    implements Listener {
        private wListener() {
        }

        @EventHandler
        public void onWorldLoad(WorldLoadEvent event) {
            World w = event.getWorld();
            if (w.getBlockAt(w.getSpawnLocation()).getWorld() != null) {
                Portal.loadAllGates(w);
            }
        }

        @EventHandler
        public void onWorldUnload(WorldUnloadEvent event) {
            Stargate.debug("onWorldUnload", "Reloading all Stargates");
            World w = event.getWorld();
            Portal.clearGates();
            for (World world : Stargate.server.getWorlds()) {
                if (world.equals((Object)w)) continue;
                Portal.loadAllGates(world);
            }
        }
    }

    private class bListener
    implements Listener {
        private bListener() {
        }

        @EventHandler
        public void onSignChange(SignChangeEvent event) {
            if (event.isCancelled()) {
                return;
            }
            Player player = event.getPlayer();
            Block block = event.getBlock();
            if (block.getType() != Material.WALL_SIGN) {
                return;
            }
            final Portal portal = Portal.createPortal(event, player);
            if (portal == null) {
                return;
            }
            Stargate.sendMessage((CommandSender)player, Stargate.getString("createMsg"), false);
            Stargate.debug("onSignChange", "Initialized stargate: " + portal.getName());
            Stargate.server.getScheduler().scheduleSyncDelayedTask((Plugin)Stargate.stargate, new Runnable(){

                @Override
                public void run() {
                    portal.drawSign();
                }
            }, 1);
        }

        @EventHandler(priority=EventPriority.HIGHEST)
        public void onBlockBreak(BlockBreakEvent event) {
            if (event.isCancelled()) {
                return;
            }
            Block block = event.getBlock();
            Player player = event.getPlayer();
            Portal portal = Portal.getByBlock(block);
            if (portal == null && Stargate.protectEntrance) {
                portal = Portal.getByEntrance(block);
            }
            if (portal == null) {
                return;
            }
            boolean deny = false;
            String denyMsg = "";
            if (!Stargate.canDestroy(player, portal)) {
                denyMsg = "Permission Denied";
                deny = true;
                Stargate.log.log(Level.INFO, "[Stargate] {0} tried to destroy gate", player.getName());
            }
            int cost = Stargate.getDestroyCost(player, portal.getGate());
            StargateDestroyEvent dEvent = new StargateDestroyEvent(portal, player, deny, denyMsg, cost);
            Stargate.server.getPluginManager().callEvent((Event)dEvent);
            if (dEvent.isCancelled()) {
                event.setCancelled(true);
                return;
            }
            if (dEvent.getDeny()) {
                Stargate.sendMessage((CommandSender)player, dEvent.getDenyReason());
                event.setCancelled(true);
                return;
            }
            cost = dEvent.getCost();
            if (cost != 0) {
                if (!Stargate.chargePlayer(player, null, cost)) {
                    Stargate.debug("onBlockBreak", "Insufficient Funds");
                    Stargate.sendMessage((CommandSender)player, Stargate.getString("inFunds"));
                    event.setCancelled(true);
                    return;
                }
                if (cost > 0) {
                    String deductMsg = Stargate.getString("ecoDeduct");
                    deductMsg = Stargate.replaceVars(deductMsg, new String[]{"%cost%", "%portal%"}, new String[]{iConomyHandler.format(cost), portal.getName()});
                    Stargate.sendMessage((CommandSender)player, deductMsg, false);
                } else if (cost < 0) {
                    String refundMsg = Stargate.getString("ecoRefund");
                    refundMsg = Stargate.replaceVars(refundMsg, new String[]{"%cost%", "%portal%"}, new String[]{iConomyHandler.format(- cost), portal.getName()});
                    Stargate.sendMessage((CommandSender)player, refundMsg, false);
                }
            }
            portal.unregister(true);
            Stargate.sendMessage((CommandSender)player, Stargate.getString("destroyMsg"), false);
        }

        @EventHandler
        public void onBlockPhysics(BlockPhysicsEvent event) {
            Block block = event.getBlock();
            Portal portal = null;
            if (block.getTypeId() == 90) {
                portal = Portal.getByEntrance(block);
            } else if (block.getTypeId() == 77) {
                portal = Portal.getByControl(block);
            }
            if (portal != null) {
                event.setCancelled(true);
            }
        }

        @EventHandler
        public void onBlockFromTo(BlockFromToEvent event) {
            Portal portal = Portal.getByEntrance(event.getBlock());
            if (portal != null) {
                event.setCancelled(event.getBlock().getY() == event.getToBlock().getY());
            }
        }

        @EventHandler
        public void onPistonExtend(BlockPistonExtendEvent event) {
            for (Block block : event.getBlocks()) {
                Portal portal = Portal.getByBlock(block);
                if (portal == null) continue;
                event.setCancelled(true);
                return;
            }
        }

        @EventHandler
        public void onPistonRetract(BlockPistonRetractEvent event) {
            if (!event.isSticky()) {
                return;
            }
            Block affected = event.getRetractLocation().getBlock();
            Portal portal = Portal.getByBlock(affected);
            if (portal != null) {
                event.setCancelled(true);
            }
        }

    }

    private class pListener
    implements Listener {
        private pListener() {
        }

        @EventHandler
        public void onPlayerJoin(PlayerJoinEvent event) {
            if (!Stargate.enableBungee) {
                return;
            }
            Player player = event.getPlayer();
            String destination = Stargate.bungeeQueue.remove(player.getName().toLowerCase());
            if (destination == null) {
                return;
            }
            Portal portal = Portal.getBungeeGate(destination);
            if (portal == null) {
                Stargate.debug("PlayerJoin", "Error fetching destination portal: " + destination);
                return;
            }
            portal.teleport(player, portal, null);
        }

        @EventHandler
        public void onPlayerPortal(PlayerPortalEvent event) {
            if (event.isCancelled()) {
                return;
            }
            Location from = event.getFrom();
            if (from == null) {
                Stargate.debug("onPlayerPortal", "From location is null. Stupid Bukkit");
                return;
            }
            World world = from.getWorld();
            int cX = from.getBlockX();
            int cY = from.getBlockY();
            int cZ = from.getBlockZ();
            for (int i = -2; i < 2; ++i) {
                for (int j = -2; j < 2; ++j) {
                    for (int k = -2; k < 2; ++k) {
                        Block b = world.getBlockAt(cX + i, cY + j, cZ + k);
                        Portal portal = Portal.getByEntrance(b);
                        if (portal == null) continue;
                        event.setCancelled(true);
                        return;
                    }
                }
            }
        }

        @EventHandler
        public void onPlayerMove(PlayerMoveEvent event) {
            if (event.isCancelled()) {
                return;
            }
            if (event.getFrom().getBlockX() == event.getTo().getBlockX() && event.getFrom().getBlockY() == event.getTo().getBlockY() && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
                return;
            }
            Player player = event.getPlayer();
            Portal portal = Portal.getByEntrance(event.getTo());
            if (portal == null || !portal.isOpen()) {
                return;
            }
            if (!portal.isOpenFor(player)) {
                Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
                portal.teleport(player, portal, event);
                return;
            }
            Portal destination = portal.getDestination(player);
            if (!portal.isBungee() && destination == null) {
                return;
            }
            boolean deny = false;
            if (portal.isBungee()) {
                if (!Stargate.canAccessServer(player, portal.getNetwork())) {
                    deny = true;
                }
            } else {
                if (!Stargate.canAccessNetwork(player, portal.getNetwork())) {
                    deny = true;
                }
                if (!Stargate.canAccessWorld(player, destination.getWorld().getName())) {
                    deny = true;
                }
            }
            if (!Stargate.canAccessPortal(player, portal, deny)) {
                Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
                portal.teleport(player, portal, event);
                portal.close(false);
                return;
            }
            int cost = Stargate.getUseCost(player, portal, destination);
            if (cost > 0) {
                Player p;
                String target;
                String string = target = portal.getGate().getToOwner() != false ? portal.getOwner() : null;
                if (!Stargate.chargePlayer(player, target, cost)) {
                    Stargate.sendMessage((CommandSender)player, "Insufficient Funds");
                    portal.close(false);
                    return;
                }
                String deductMsg = Stargate.getString("ecoDeduct");
                deductMsg = Stargate.replaceVars(deductMsg, new String[]{"%cost%", "%portal%"}, new String[]{iConomyHandler.format(cost), portal.getName()});
                Stargate.sendMessage((CommandSender)player, deductMsg, false);
                if (target != null && (p = Stargate.server.getPlayer(target)) != null) {
                    String obtainedMsg = Stargate.getString("ecoObtain");
                    obtainedMsg = Stargate.replaceVars(obtainedMsg, new String[]{"%cost%", "%portal%"}, new String[]{iConomyHandler.format(cost), portal.getName()});
                    Stargate.sendMessage((CommandSender)p, obtainedMsg, false);
                }
            }
            Stargate.sendMessage((CommandSender)player, Stargate.getString("teleportMsg"), false);
            if (portal.isBungee()) {
                if (!Stargate.enableBungee) {
                    player.sendMessage(Stargate.getString("bungeeDisabled"));
                    portal.close(false);
                    return;
                }
                portal.teleport(player, portal, event);
                try {
                    String msg = event.getPlayer().getName() + "#@#" + portal.getDestinationName();
                    ByteArrayOutputStream bao = new ByteArrayOutputStream();
                    DataOutputStream msgData = new DataOutputStream(bao);
                    msgData.writeUTF("Forward");
                    msgData.writeUTF(portal.getNetwork());
                    msgData.writeUTF("SGBungee");
                    msgData.writeShort(msg.length());
                    msgData.writeBytes(msg);
                    player.sendPluginMessage((Plugin)Stargate.stargate, "BungeeCord", bao.toByteArray());
                }
                catch (IOException ex) {
                    Stargate.log.severe("[Stargate] Error sending BungeeCord teleport packet");
                    return;
                }
                try {
                    ByteArrayOutputStream bao = new ByteArrayOutputStream();
                    DataOutputStream msgData = new DataOutputStream(bao);
                    msgData.writeUTF("Connect");
                    msgData.writeUTF(portal.getNetwork());
                    player.sendPluginMessage((Plugin)Stargate.stargate, "BungeeCord", bao.toByteArray());
                    bao.reset();
                }
                catch (IOException ex) {
                    Stargate.log.severe("[Stargate] Error sending BungeeCord connect packet");
                    return;
                }
                portal.close(false);
                return;
            }
            destination.teleport(player, portal, event);
            portal.close(false);
        }

        @EventHandler
        public void onPlayerInteract(PlayerInteractEvent event) {
            Player player = event.getPlayer();
            Block block = null;
            if (event.isCancelled() && event.getAction() == Action.RIGHT_CLICK_AIR) {
                try {
                    player.getTargetBlock((Set)null, 5);
                }
                catch (IllegalStateException ex) {
                    return;
                }
            } else {
                block = event.getClickedBlock();
            }
            if (block == null) {
                return;
            }
            if (event.getAction() == Action.RIGHT_CLICK_BLOCK || event.getAction() == Action.RIGHT_CLICK_AIR) {
                if (block.getType() == Material.WALL_SIGN) {
                    Portal portal = Portal.getByBlock(block);
                    if (portal == null) {
                        return;
                    }
                    event.setUseItemInHand(Event.Result.DENY);
                    event.setUseInteractedBlock(Event.Result.DENY);
                    boolean deny = false;
                    if (!Stargate.canAccessNetwork(player, portal.getNetwork())) {
                        deny = true;
                    }
                    if (!Stargate.canAccessPortal(player, portal, deny)) {
                        Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
                        return;
                    }
                    if (!portal.isOpen() && !portal.isFixed()) {
                        portal.cycleDestination(player);
                    }
                    return;
                }
                if (block.getType() == Material.STONE_BUTTON) {
                    Portal portal = Portal.getByBlock(block);
                    if (portal == null) {
                        return;
                    }
                    event.setUseItemInHand(Event.Result.DENY);
                    event.setUseInteractedBlock(Event.Result.DENY);
                    boolean deny = false;
                    if (!Stargate.canAccessNetwork(player, portal.getNetwork())) {
                        deny = true;
                    }
                    if (!Stargate.canAccessPortal(player, portal, deny)) {
                        Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
                        return;
                    }
                    Stargate.openPortal(player, portal);
                    if (portal.isOpenFor(player)) {
                        event.setUseInteractedBlock(Event.Result.ALLOW);
                    }
                }
                return;
            }
            if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
                if (block.getType() == Material.WALL_SIGN) {
                    Portal portal = Portal.getByBlock(block);
                    if (portal == null) {
                        return;
                    }
                    event.setUseInteractedBlock(Event.Result.DENY);
                    if (player.getGameMode().equals((Object)GameMode.CREATIVE)) {
                        event.setCancelled(true);
                    }
                    boolean deny = false;
                    if (!Stargate.canAccessNetwork(player, portal.getNetwork())) {
                        deny = true;
                    }
                    if (!Stargate.canAccessPortal(player, portal, deny)) {
                        Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
                        return;
                    }
                    if (!portal.isOpen() && !portal.isFixed()) {
                        portal.cycleDestination(player, -1);
                    }
                    return;
                }
                if (block.getType() == Material.STONE_BUTTON) {
                    Portal portal = Portal.getByBlock(block);
                    if (portal == null) {
                        return;
                    }
                    event.setUseInteractedBlock(Event.Result.DENY);
                    if (player.getGameMode().equals((Object)GameMode.CREATIVE)) {
                        event.setCancelled(true);
                    }
                    boolean deny = false;
                    if (!Stargate.canAccessNetwork(player, portal.getNetwork())) {
                        deny = true;
                    }
                    if (!Stargate.canAccessPortal(player, portal, deny)) {
                        Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
                        return;
                    }
                    Stargate.openPortal(player, portal);
                }
            }
        }
    }

    private class vListener
    implements Listener {
        private vListener() {
        }

        @EventHandler
        public void onVehicleMove(VehicleMoveEvent event) {
            if (!Stargate.handleVehicles) {
                return;
            }
            Entity passenger = event.getVehicle().getPassenger();
            Vehicle vehicle = event.getVehicle();
            Portal portal = Portal.getByEntrance(event.getTo());
            if (portal == null || !portal.isOpen()) {
                return;
            }
            if (portal.isBungee()) {
                return;
            }
            if (passenger instanceof Player) {
                Player player = (Player)passenger;
                if (!portal.isOpenFor(player)) {
                    Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
                    return;
                }
                Portal dest = portal.getDestination(player);
                if (dest == null) {
                    return;
                }
                boolean deny = false;
                if (!Stargate.canAccessNetwork(player, portal.getNetwork())) {
                    deny = true;
                }
                if (!Stargate.canAccessWorld(player, dest.getWorld().getName())) {
                    deny = true;
                }
                if (!Stargate.canAccessPortal(player, portal, deny)) {
                    Stargate.sendMessage((CommandSender)player, Stargate.getString("denyMsg"));
                    portal.close(false);
                    return;
                }
                int cost = Stargate.getUseCost(player, portal, dest);
                if (cost > 0) {
                    Player p;
                    String target;
                    String string = target = portal.getGate().getToOwner() != false ? portal.getOwner() : null;
                    if (!Stargate.chargePlayer(player, target, cost)) {
                        Stargate.sendMessage((CommandSender)player, Stargate.getString("inFunds"));
                        portal.close(false);
                        return;
                    }
                    String deductMsg = Stargate.getString("ecoDeduct");
                    deductMsg = Stargate.replaceVars(deductMsg, new String[]{"%cost%", "%portal%"}, new String[]{iConomyHandler.format(cost), portal.getName()});
                    Stargate.sendMessage((CommandSender)player, deductMsg, false);
                    if (target != null && (p = Stargate.server.getPlayer(target)) != null) {
                        String obtainedMsg = Stargate.getString("ecoObtain");
                        obtainedMsg = Stargate.replaceVars(obtainedMsg, new String[]{"%cost%", "%portal%"}, new String[]{iConomyHandler.format(cost), portal.getName()});
                        Stargate.sendMessage((CommandSender)p, obtainedMsg, false);
                    }
                }
                Stargate.sendMessage((CommandSender)player, Stargate.getString("teleportMsg"), false);
                dest.teleport(vehicle);
                portal.close(false);
            } else {
                Portal dest = portal.getDestination();
                if (dest == null) {
                    return;
                }
                dest.teleport(vehicle);
            }
        }
    }

}

