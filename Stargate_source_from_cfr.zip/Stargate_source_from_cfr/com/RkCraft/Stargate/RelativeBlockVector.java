/*
 * Decompiled with CFR 0_122.
 */
package com.RkCraft.Stargate;

public class RelativeBlockVector {
    private int right = 0;
    private int depth = 0;
    private int distance = 0;

    public RelativeBlockVector(int right, int depth, int distance) {
        this.right = right;
        this.depth = depth;
        this.distance = distance;
    }

    public int getRight() {
        return this.right;
    }

    public int getDepth() {
        return this.depth;
    }

    public int getDistance() {
        return this.distance;
    }
}

