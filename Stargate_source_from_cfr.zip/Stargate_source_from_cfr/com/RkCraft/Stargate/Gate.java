/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 */
package com.RkCraft.Stargate;

import com.RkCraft.Stargate.Blox;
import com.RkCraft.Stargate.RelativeBlockVector;
import com.RkCraft.Stargate.Stargate;
import com.RkCraft.Stargate.iConomyHandler;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Material;
import org.bukkit.block.Block;

public class Gate {
    public static final int ANYTHING = -1;
    public static final int ENTRANCE = -2;
    public static final int CONTROL = -3;
    public static final int EXIT = -4;
    private static final HashMap<String, Gate> gates = new HashMap();
    private static final HashMap<Integer, ArrayList<Gate>> controlBlocks = new HashMap();
    private static final HashSet<Integer> frameBlocks = new HashSet();
    private final String filename;
    private final Character[][] layout;
    private final HashMap<Character, Integer> types;
    private final HashMap<Character, Integer> metadata;
    private RelativeBlockVector[] entrances = new RelativeBlockVector[0];
    private RelativeBlockVector[] border = new RelativeBlockVector[0];
    private RelativeBlockVector[] controls = new RelativeBlockVector[0];
    private RelativeBlockVector exitBlock = null;
    private final HashMap<RelativeBlockVector, Integer> exits = new HashMap();
    private int portalBlockOpen = Material.PORTAL.getId();
    private int portalBlockClosed = Material.AIR.getId();
    private int useCost = -1;
    private int createCost = -1;
    private int destroyCost = -1;
    private boolean toOwner = false;

    public Gate(String filename, Character[][] layout, HashMap<Character, Integer> types, HashMap<Character, Integer> metadata) {
        this.filename = filename;
        this.layout = layout;
        this.metadata = metadata;
        this.types = types;
        this.populateCoordinates();
    }

    private void populateCoordinates() {
        int x;
        ArrayList<RelativeBlockVector> entranceList = new ArrayList<RelativeBlockVector>();
        ArrayList<RelativeBlockVector> borderList = new ArrayList<RelativeBlockVector>();
        ArrayList<RelativeBlockVector> controlList = new ArrayList<RelativeBlockVector>();
        RelativeBlockVector[] relativeExits = new RelativeBlockVector[this.layout[0].length];
        int[] exitDepths = new int[this.layout[0].length];
        RelativeBlockVector lastExit = null;
        for (int y = 0; y < this.layout.length; ++y) {
            for (int x2 = 0; x2 < this.layout[y].length; ++x2) {
                Integer id = this.types.get(this.layout[y][x2]);
                if (this.layout[y][x2].charValue() == '-') {
                    controlList.add(new RelativeBlockVector(x2, y, 0));
                }
                if (id == -2 || id == -4) {
                    entranceList.add(new RelativeBlockVector(x2, y, 0));
                    exitDepths[x2] = y;
                    if (id != -4) continue;
                    this.exitBlock = new RelativeBlockVector(x2, y, 0);
                    continue;
                }
                if (id == -1) continue;
                borderList.add(new RelativeBlockVector(x2, y, 0));
            }
        }
        for (x = 0; x < exitDepths.length; ++x) {
            relativeExits[x] = new RelativeBlockVector(x, exitDepths[x], 0);
        }
        for (x = relativeExits.length - 1; x >= 0; --x) {
            if (relativeExits[x] != null) {
                lastExit = relativeExits[x];
            } else {
                relativeExits[x] = lastExit;
            }
            if (exitDepths[x] <= 0) continue;
            this.exits.put(relativeExits[x], x);
        }
        this.entrances = entranceList.toArray(this.entrances);
        this.border = borderList.toArray(this.border);
        this.controls = controlList.toArray(this.controls);
    }

    public void save(String gateFolder) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(gateFolder + this.filename));
            Throwable throwable = null;
            try {
                this.writeConfig(bw, "portal-open", this.portalBlockOpen);
                this.writeConfig(bw, "portal-closed", this.portalBlockClosed);
                if (this.useCost != -1) {
                    this.writeConfig(bw, "usecost", this.useCost);
                }
                if (this.createCost != -1) {
                    this.writeConfig(bw, "createcost", this.createCost);
                }
                if (this.destroyCost != -1) {
                    this.writeConfig(bw, "destroycost", this.destroyCost);
                }
                this.writeConfig(bw, "toowner", this.toOwner);
                for (Character type : this.types.keySet()) {
                    Integer value = this.types.get(type);
                    if (value < 0) continue;
                    bw.append(type.charValue());
                    bw.append('=');
                    bw.append(value.toString());
                    Integer mData = this.metadata.get(type);
                    if (mData != null) {
                        bw.append(':');
                        bw.append(mData.toString());
                    }
                    bw.newLine();
                }
                bw.newLine();
                Character[][] arr$ = this.layout;
                int len$ = arr$.length;
                for (int i$ = 0; i$ < len$; ++i$) {
                    Character[] layout1;
                    for (Character symbol : layout1 = arr$[i$]) {
                        bw.append(symbol.charValue());
                    }
                    bw.newLine();
                }
            }
            catch (Throwable x2) {
                throwable = x2;
                throw x2;
            }
            finally {
                if (bw != null) {
                    if (throwable != null) {
                        try {
                            bw.close();
                        }
                        catch (Throwable x2) {
                            throwable.addSuppressed(x2);
                        }
                    } else {
                        bw.close();
                    }
                }
            }
        }
        catch (IOException ex) {
            Stargate.log.log(Level.SEVERE, "Could not save Gate {0} - {1}", new Object[]{this.filename, ex.getMessage()});
        }
    }

    private void writeConfig(BufferedWriter bw, String key, int value) throws IOException {
        bw.append(String.format("%s=%d", key, value));
        bw.newLine();
    }

    private void writeConfig(BufferedWriter bw, String key, boolean value) throws IOException {
        bw.append(String.format("%s=%b", key, value));
        bw.newLine();
    }

    public Character[][] getLayout() {
        return this.layout;
    }

    public HashMap<Character, Integer> getTypes() {
        return this.types;
    }

    public HashMap<Character, Integer> getMetaData() {
        return this.metadata;
    }

    public RelativeBlockVector[] getEntrances() {
        return this.entrances;
    }

    public RelativeBlockVector[] getBorder() {
        return this.border;
    }

    public RelativeBlockVector[] getControls() {
        return this.controls;
    }

    public HashMap<RelativeBlockVector, Integer> getExits() {
        return this.exits;
    }

    public RelativeBlockVector getExit() {
        return this.exitBlock;
    }

    public int getControlBlock() {
        return this.types.get(Character.valueOf('-'));
    }

    public String getFilename() {
        return this.filename;
    }

    public int getPortalBlockOpen() {
        return this.portalBlockOpen;
    }

    public void setPortalBlockOpen(int type) {
        this.portalBlockOpen = type;
    }

    public int getPortalBlockClosed() {
        return this.portalBlockClosed;
    }

    public void setPortalBlockClosed(int type) {
        this.portalBlockClosed = type;
    }

    public int getUseCost() {
        if (this.useCost < 0) {
            return iConomyHandler.useCost;
        }
        return this.useCost;
    }

    public Integer getCreateCost() {
        if (this.createCost < 0) {
            return iConomyHandler.createCost;
        }
        return this.createCost;
    }

    public Integer getDestroyCost() {
        if (this.destroyCost < 0) {
            return iConomyHandler.destroyCost;
        }
        return this.destroyCost;
    }

    public Boolean getToOwner() {
        return this.toOwner;
    }

    public boolean matches(Blox topleft, int modX, int modZ) {
        return this.matches(topleft, modX, modZ, false);
    }

    public boolean matches(Blox topleft, int modX, int modZ, boolean onCreate) {
        for (int y = 0; y < this.layout.length; ++y) {
            for (int x = 0; x < this.layout[y].length; ++x) {
                int id = this.types.get(this.layout[y][x]);
                if (id == -2 || id == -4) {
                    if (Stargate.ignoreEntrance) continue;
                    int type = topleft.modRelative(x, y, 0, modX, 1, modZ).getType();
                    if (onCreate && type == Material.AIR.getId() || type == this.portalBlockClosed || type == this.portalBlockOpen || (this.portalBlockOpen == Material.WATER.getId() || this.portalBlockOpen == Material.STATIONARY_WATER.getId()) && (type == Material.WATER.getId() || type == Material.STATIONARY_WATER.getId()) || (this.portalBlockOpen == Material.LAVA.getId() || this.portalBlockOpen == Material.STATIONARY_LAVA.getId()) && (type == Material.LAVA.getId() || type == Material.STATIONARY_LAVA.getId())) continue;
                    Stargate.debug("Gate::Matches", "Entrance/Exit Material Mismatch: " + type);
                    return false;
                }
                if (id == -1) continue;
                if (topleft.modRelative(x, y, 0, modX, 1, modZ).getType() != id) {
                    Stargate.debug("Gate::Matches", "Block Type Mismatch: " + topleft.modRelative(x, y, 0, modX, 1, modZ).getType() + " != " + id);
                    return false;
                }
                Integer mData = this.metadata.get(this.layout[y][x]);
                if (mData == null || topleft.modRelative(x, y, 0, modX, 1, modZ).getData() == mData.intValue()) continue;
                Stargate.debug("Gate::Matches", "Block Data Mismatch: " + topleft.modRelative(x, y, 0, modX, 1, modZ).getData() + " != " + mData);
                return false;
            }
        }
        return true;
    }

    public static void registerGate(Gate gate) {
        gates.put(gate.getFilename(), gate);
        int blockID = gate.getControlBlock();
        if (!controlBlocks.containsKey(blockID)) {
            controlBlocks.put(blockID, new ArrayList());
        }
        controlBlocks.get(blockID).add(gate);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static Gate loadGate(File file) {
        ArrayList design;
        HashMap<String, String> config;
        HashMap<Character, Integer> metadata;
        int cols;
        HashSet<Integer> frameTypes;
        HashMap<Character, Integer> types;
        String[] split;
        Scanner scanner = null;
        boolean designing = false;
        design = new ArrayList();
        types = new HashMap<Character, Integer>();
        metadata = new HashMap<Character, Integer>();
        config = new HashMap<String, String>();
        frameTypes = new HashSet<Integer>();
        cols = 0;
        types.put(Character.valueOf('.'), -2);
        types.put(Character.valueOf('*'), -4);
        types.put(Character.valueOf(' '), -1);
        try {
            scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (designing) {
                    ArrayList<Character> row = new ArrayList<Character>();
                    if (line.length() > cols) {
                        cols = line.length();
                    }
                    char[] arr$ = line.toCharArray();
                    int len$ = arr$.length;
                    for (int i$ = 0; i$ < len$; ++i$) {
                        Character symbol = Character.valueOf(arr$[i$]);
                        if (symbol.equals(Character.valueOf('?')) || !types.containsKey(symbol)) {
                            Stargate.log.log(Level.SEVERE, "Could not load Gate {0} - Unknown symbol ''{1}'' in diagram", new Object[]{file.getName(), symbol});
                            Gate gate = null;
                            return gate;
                        }
                        row.add(symbol);
                    }
                    design.add(row);
                    continue;
                }
                if (line.isEmpty() || !line.contains("=")) {
                    designing = true;
                    continue;
                }
                split = line.split("=");
                String key = split[0].trim();
                String value = split[1].trim();
                if (key.length() == 1) {
                    Character symbol = Character.valueOf(key.charAt(0));
                    if (value.contains(":")) {
                        split = value.split(":");
                        value = split[0].trim();
                        String mData = split[1].trim();
                        metadata.put(symbol, Integer.parseInt(mData));
                    }
                    Integer id = Integer.parseInt(value);
                    types.put(symbol, id);
                    frameTypes.add(id);
                    continue;
                }
                config.put(key, value);
            }
        }
        catch (FileNotFoundException | NumberFormatException ex) {
            Stargate.log.log(Level.SEVERE, "Could not load Gate {0} - Invalid block ID given", file.getName());
            split = null;
            return split;
        }
        finally {
            if (scanner != null) {
                scanner.close();
            }
        }
        Character[][] layout = new Character[design.size()][cols];
        for (int y = 0; y < design.size(); ++y) {
            ArrayList row = (ArrayList)design.get(y);
            Character[] result = new Character[cols];
            for (int x = 0; x < cols; ++x) {
                result[x] = x < row.size() ? (Character)row.get(x) : Character.valueOf(' ');
            }
            layout[y] = result;
        }
        Gate gate = new Gate(file.getName(), layout, types, metadata);
        gate.portalBlockOpen = Gate.readConfig(config, gate, file, "portal-open", gate.portalBlockOpen);
        gate.portalBlockClosed = Gate.readConfig(config, gate, file, "portal-closed", gate.portalBlockClosed);
        gate.useCost = Gate.readConfig(config, gate, file, "usecost", -1);
        gate.destroyCost = Gate.readConfig(config, gate, file, "destroycost", -1);
        gate.createCost = Gate.readConfig(config, gate, file, "createcost", -1);
        boolean bl = gate.toOwner = config.containsKey("toowner") ? Boolean.valueOf(config.get("toowner")) : iConomyHandler.toOwner;
        if (gate.getControls().length != 2) {
            Stargate.log.log(Level.SEVERE, "Could not load Gate {0} - Gates must have exactly 2 control points.", file.getName());
            return null;
        }
        frameBlocks.addAll(frameTypes);
        gate.save(file.getParent() + "/");
        return gate;
    }

    private static int readConfig(HashMap<String, String> config, Gate gate, File file, String key, int def) {
        if (config.containsKey(key)) {
            try {
                return Integer.parseInt(config.get(key));
            }
            catch (NumberFormatException ex) {
                Stargate.log.log(Level.WARNING, String.format("%s reading %s: %s is not numeric", ex.getClass().getName(), file, key));
            }
        }
        return def;
    }

    public static void loadGates(String gateFolder) {
        File dir = new File(gateFolder);
        File[] files = dir.exists() ? dir.listFiles(new StargateFilenameFilter()) : new File[]{};
        if (files.length == 0) {
            dir.mkdir();
            Gate.populateDefaults(gateFolder);
        } else {
            for (File file : files) {
                Gate gate = Gate.loadGate(file);
                if (gate == null) continue;
                Gate.registerGate(gate);
            }
        }
    }

    public static void populateDefaults(String gateFolder) {
        int Obsidian = Material.OBSIDIAN.getId();
        Character[][] layout = new Character[][]{{Character.valueOf(' '), Character.valueOf('X'), Character.valueOf('X'), Character.valueOf(' ')}, {Character.valueOf('X'), Character.valueOf('.'), Character.valueOf('.'), Character.valueOf('X')}, {Character.valueOf('-'), Character.valueOf('.'), Character.valueOf('.'), Character.valueOf('-')}, {Character.valueOf('X'), Character.valueOf('*'), Character.valueOf('.'), Character.valueOf('X')}, {Character.valueOf(' '), Character.valueOf('X'), Character.valueOf('X'), Character.valueOf(' ')}};
        HashMap<Character, Integer> types = new HashMap<Character, Integer>();
        types.put(Character.valueOf('.'), -2);
        types.put(Character.valueOf('*'), -4);
        types.put(Character.valueOf(' '), -1);
        types.put(Character.valueOf('X'), Obsidian);
        types.put(Character.valueOf('-'), Obsidian);
        HashMap<Character, Integer> metadata = new HashMap<Character, Integer>();
        Gate gate = new Gate("nethergate.gate", layout, types, metadata);
        gate.save(gateFolder);
        Gate.registerGate(gate);
    }

    public static Gate[] getGatesByControlBlock(Block block) {
        return Gate.getGatesByControlBlock(block.getTypeId());
    }

    public static Gate[] getGatesByControlBlock(int type) {
        Gate[] result = new Gate[]{};
        ArrayList<Gate> lookup = controlBlocks.get(type);
        if (lookup != null) {
            result = lookup.toArray(result);
        }
        return result;
    }

    public static Gate getGateByName(String name) {
        return gates.get(name);
    }

    public static int getGateCount() {
        return gates.size();
    }

    public static boolean isGateBlock(int type) {
        return frameBlocks.contains(type);
    }

    public static void clearGates() {
        gates.clear();
        controlBlocks.clear();
        frameBlocks.clear();
    }

    static class StargateFilenameFilter
    implements FilenameFilter {
        StargateFilenameFilter() {
        }

        @Override
        public boolean accept(File dir, String name) {
            return name.endsWith(".gate");
        }
    }

}

