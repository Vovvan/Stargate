/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.HandlerList
 */
package com.RkCraft.Stargate.event;

import com.RkCraft.Stargate.Portal;
import com.RkCraft.Stargate.event.StargateEvent;
import org.bukkit.event.HandlerList;

public class StargateDeactivateEvent
extends StargateEvent {
    private static final HandlerList handlers = new HandlerList();

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public StargateDeactivateEvent(Portal portal) {
        super("StargatDeactivateEvent", portal);
    }
}

