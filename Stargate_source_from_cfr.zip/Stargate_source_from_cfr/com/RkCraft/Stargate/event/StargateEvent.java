/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.Event
 */
package com.RkCraft.Stargate.event;

import com.RkCraft.Stargate.Portal;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

public abstract class StargateEvent
extends Event
implements Cancellable {
    protected Portal portal;
    protected boolean cancelled;

    public StargateEvent(String event, Portal portal) {
        this.portal = portal;
        this.cancelled = false;
    }

    public Portal getPortal() {
        return this.portal;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }
}

