/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.entity.Player
 *  org.bukkit.event.HandlerList
 */
package com.RkCraft.Stargate.event;

import com.RkCraft.Stargate.Portal;
import com.RkCraft.Stargate.event.StargateEvent;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

public class StargatePortalEvent
extends StargateEvent {
    private final Player player;
    private final Portal destination;
    private Location exit;
    private static final HandlerList handlers = new HandlerList();

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public StargatePortalEvent(Player player, Portal portal, Portal dest, Location exit) {
        super("StargatePortalEvent", portal);
        this.player = player;
        this.destination = dest;
        this.exit = exit;
    }

    public Player getPlayer() {
        return this.player;
    }

    public Portal getDestination() {
        return this.destination;
    }

    public Location getExit() {
        return this.exit;
    }

    public void setExit(Location loc) {
        this.exit = loc;
    }
}

