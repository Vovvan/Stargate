/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.HandlerList
 */
package com.RkCraft.Stargate.event;

import com.RkCraft.Stargate.Portal;
import com.RkCraft.Stargate.event.StargateEvent;
import java.util.ArrayList;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

public class StargateActivateEvent
extends StargateEvent {
    private final Player player;
    private ArrayList<String> destinations;
    private String destination;
    private static final HandlerList handlers = new HandlerList();

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public StargateActivateEvent(Portal portal, Player player, ArrayList<String> destinations, String destination) {
        super("StargatActivateEvent", portal);
        this.player = player;
        this.destinations = destinations;
        this.destination = destination;
    }

    public Player getPlayer() {
        return this.player;
    }

    public ArrayList<String> getDestinations() {
        return this.destinations;
    }

    public void setDestinations(ArrayList<String> destinations) {
        this.destinations = destinations;
    }

    public String getDestination() {
        return this.destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }
}

