/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.HandlerList
 */
package com.RkCraft.Stargate.event;

import com.RkCraft.Stargate.Portal;
import com.RkCraft.Stargate.event.StargateEvent;
import org.bukkit.event.HandlerList;

public class StargateCloseEvent
extends StargateEvent {
    private boolean force;
    private static final HandlerList handlers = new HandlerList();

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public StargateCloseEvent(Portal portal, boolean force) {
        super("StargateCloseEvent", portal);
        this.force = force;
    }

    public boolean getForce() {
        return this.force;
    }

    public void setForce(boolean force) {
        this.force = force;
    }
}

