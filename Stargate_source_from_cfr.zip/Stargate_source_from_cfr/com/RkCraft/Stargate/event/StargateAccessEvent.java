/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.HandlerList
 */
package com.RkCraft.Stargate.event;

import com.RkCraft.Stargate.Portal;
import com.RkCraft.Stargate.event.StargateEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

public class StargateAccessEvent
extends StargateEvent {
    private final Player player;
    private boolean deny;
    private static final HandlerList handlers = new HandlerList();

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public StargateAccessEvent(Player player, Portal portal, boolean deny) {
        super("StargateAccessEvent", portal);
        this.player = player;
        this.deny = deny;
    }

    public boolean getDeny() {
        return this.deny;
    }

    public void setDeny(boolean deny) {
        this.deny = deny;
    }

    public Player getPlayer() {
        return this.player;
    }
}

