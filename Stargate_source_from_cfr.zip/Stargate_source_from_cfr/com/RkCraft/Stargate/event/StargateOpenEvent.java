/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.HandlerList
 */
package com.RkCraft.Stargate.event;

import com.RkCraft.Stargate.Portal;
import com.RkCraft.Stargate.event.StargateEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

public class StargateOpenEvent
extends StargateEvent {
    private final Player player;
    private boolean force;
    private static final HandlerList handlers = new HandlerList();

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public StargateOpenEvent(Player player, Portal portal, boolean force) {
        super("StargateOpenEvent", portal);
        this.player = player;
        this.force = force;
    }

    public Player getPlayer() {
        return this.player;
    }

    public boolean getForce() {
        return this.force;
    }

    public void setForce(boolean force) {
        this.force = force;
    }
}

