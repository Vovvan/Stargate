/*
 * Decompiled with CFR 0_122.
 */
package com.RkCraft.Stargate;

import com.RkCraft.Stargate.Stargate;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LangLoader {
    private final String UTF8_BOM = "\ufeff";
    private final String datFolder;
    private String lang;
    private HashMap<String, String> strList;
    private final HashMap<String, String> defList;

    public LangLoader(String datFolder, String lang) {
        this.lang = lang;
        this.datFolder = datFolder;
        File tmp = new File(datFolder, lang + ".txt");
        if (!tmp.exists()) {
            tmp.getParentFile().mkdirs();
        }
        this.updateLanguage(lang);
        this.strList = this.load(lang);
        InputStream is = Stargate.class.getResourceAsStream("resources/" + lang + ".txt");
        if (is != null) {
            this.defList = this.load("en", is);
        } else {
            this.defList = null;
            Stargate.log.severe("[Stargate] Error loading backup language. There may be missing text ingame");
        }
    }

    public boolean reload() {
        this.updateLanguage(this.lang);
        this.strList = this.load(this.lang);
        return true;
    }

    public String getString(String name) {
        String val = this.strList.get(name);
        if (val == null && this.defList != null) {
            val = this.defList.get(name);
        }
        if (val == null) {
            return "";
        }
        return val;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void updateLanguage(String lang) {
        keyList = new ArrayList<String>();
        valList = new ArrayList<String>();
        curLang = this.load(lang);
        is = Stargate.class.getResourceAsStream("resources/" + lang + ".txt");
        if (is == null) {
            return;
        }
        updated = false;
        fos = null;
        try {
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);
            var10_13 = null;
            try {
                line = br.readLine();
                firstLine = true;
                while (line != null) {
                    if (firstLine) {
                        line = this.removeUTF8BOM(line);
                    }
                    firstLine = false;
                    eq = line.indexOf(61);
                    if (eq == -1) {
                        keyList.add("");
                        valList.add("");
                        line = br.readLine();
                        continue;
                    }
                    key = line.substring(0, eq);
                    val = line.substring(eq);
                    if (curLang == null || curLang.get(key) == null) {
                        keyList.add(key);
                        valList.add(val);
                        updated = true;
                    } else {
                        keyList.add(key);
                        valList.add("=" + curLang.get(key));
                        curLang.remove(key);
                    }
                    line = br.readLine();
                }
            }
            catch (Throwable x2) {
                var10_13 = x2;
                throw x2;
            }
            finally {
                if (br != null) {
                    if (var10_13 != null) {
                        try {
                            br.close();
                        }
                        catch (Throwable x2) {
                            var10_13.addSuppressed(x2);
                        }
                    } else {
                        br.close();
                    }
                }
            }
            fos = new FileOutputStream(this.datFolder + lang + ".txt");
            out = new OutputStreamWriter((OutputStream)fos, "UTF8");
            bw = new BufferedWriter(out);
            x2 = null;
            try {
                for (i = 0; i < keyList.size(); ++i) {
                    bw.write((String)keyList.get(i) + (String)valList.get(i));
                    bw.newLine();
                }
                bw.newLine();
                for (String key : curLang.keySet()) {
                    bw.write(key + "=" + curLang.get(key));
                    bw.newLine();
                }
            }
            catch (Throwable x2) {
                x2 = x2;
                throw x2;
            }
            finally {
                if (bw != null) {
                    if (x2 != null) {
                        try {
                            bw.close();
                        }
                        catch (Throwable x2) {
                            x2.addSuppressed(x2);
                        }
                    } else {
                        bw.close();
                    }
                }
            }
            ** if (fos == null) goto lbl-1000
        }
        catch (Exception isr) {
            if (fos != null) {
                try {
                    fos.close();
                }
                catch (Exception isr) {}
            }
            catch (Throwable var20_28) {
                if (fos == null) throw var20_28;
                try {
                    fos.close();
                    throw var20_28;
                }
                catch (Exception var21_29) {
                    // empty catch block
                }
                throw var20_28;
            }
        }
lbl-1000: // 1 sources:
        {
            try {
                fos.close();
            }
            catch (Exception isr) {}
        }
lbl-1000: // 2 sources:
        {
        }
        if (updated == false) return;
        Stargate.log.log(Level.INFO, "[Stargate] Your language file ({0}.txt) has been updated", lang);
    }

    private HashMap<String, String> load(String lang) {
        return this.load(lang, null);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private HashMap<String, String> load(String lang, InputStream is) {
        HashMap<String, String> strings;
        strings = new HashMap<String, String>();
        FileInputStream fis = null;
        InputStreamReader isr = null;
        try {
            if (is == null) {
                fis = new FileInputStream(this.datFolder + lang + ".txt");
                isr = new InputStreamReader((InputStream)fis, "UTF8");
            } else {
                isr = new InputStreamReader(is, "UTF8");
            }
            BufferedReader br = new BufferedReader(isr);
            String line = br.readLine();
            boolean firstLine = true;
            while (line != null) {
                if (firstLine) {
                    line = this.removeUTF8BOM(line);
                }
                firstLine = false;
                int eq = line.indexOf(61);
                if (eq == -1) {
                    line = br.readLine();
                    continue;
                }
                String key = line.substring(0, eq);
                String val = line.substring(eq + 1);
                strings.put(key, val);
                line = br.readLine();
            }
        }
        catch (Exception ex) {
            HashMap<String, String> line = null;
            return line;
        }
        finally {
            if (fis != null) {
                try {
                    fis.close();
                }
                catch (Exception firstLine) {}
            }
        }
        return strings;
    }

    public void debug() {
        Set<String> keys = this.strList.keySet();
        for (String key : keys) {
            Stargate.debug("LangLoader::Debug::strList", key + " => " + this.strList.get(key));
        }
        if (this.defList == null) {
            return;
        }
        keys = this.defList.keySet();
        for (String key : keys) {
            Stargate.debug("LangLoader::Debug::defList", key + " => " + this.defList.get(key));
        }
    }

    private String removeUTF8BOM(String s) {
        if (s.startsWith("\ufeff")) {
            s = s.substring(1);
        }
        return s;
    }
}

