/*
 * Decompiled with CFR 0_122.
 */
package com.RkCraft.Stargate;

import com.RkCraft.Stargate.Blox;

public class BloxPopulator {
    private Blox blox;
    private int nextMat;
    private byte nextData;

    public BloxPopulator(Blox b, int m) {
        this.blox = b;
        this.nextMat = m;
        this.nextData = 0;
    }

    public BloxPopulator(Blox b, int m, byte d) {
        this.blox = b;
        this.nextMat = m;
        this.nextData = d;
    }

    public void setBlox(Blox b) {
        this.blox = b;
    }

    public void setMat(int m) {
        this.nextMat = m;
    }

    public void setData(byte d) {
        this.nextData = d;
    }

    public Blox getBlox() {
        return this.blox;
    }

    public int getMat() {
        return this.nextMat;
    }

    public byte getData() {
        return this.nextData;
    }
}

