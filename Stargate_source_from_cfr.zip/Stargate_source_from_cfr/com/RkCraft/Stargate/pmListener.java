/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  org.bukkit.Server
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.plugin.messaging.PluginMessageListener
 */
package com.RkCraft.Stargate;

import com.RkCraft.Stargate.Portal;
import com.RkCraft.Stargate.Stargate;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.messaging.PluginMessageListener;

public class pmListener
implements PluginMessageListener {
    public void onPluginMessageReceived(String channel, Player unused, byte[] message) {
        byte[] data;
        String inChannel;
        if (!Stargate.enableBungee || !channel.equals("BungeeCord")) {
            return;
        }
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(message));
            inChannel = in.readUTF();
            short len = in.readShort();
            data = new byte[len];
            in.readFully(data);
        }
        catch (IOException ex) {
            Stargate.log.severe("[Stargate] Error receiving BungeeCord message");
            return;
        }
        if (!inChannel.equals("SGBungee")) {
            return;
        }
        String msg = new String(data);
        String[] parts = msg.split("#@#");
        String playerName = parts[0];
        String destination = parts[1];
        Player player = Stargate.server.getPlayer(playerName);
        if (player == null) {
            Stargate.bungeeQueue.put(playerName.toLowerCase(), destination);
        } else {
            Portal dest = Portal.getBungeeGate(destination);
            if (dest == null) {
                Stargate.log.log(Level.INFO, "[Stargate] Bungee gate {0} does not exist", destination);
                return;
            }
            dest.teleport(player, dest, null);
        }
    }
}

