/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.Vault
 *  net.milkbowl.vault.economy.Economy
 *  net.milkbowl.vault.economy.EconomyResponse
 *  org.bukkit.Server
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginDescriptionFile
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.plugin.RegisteredServiceProvider
 *  org.bukkit.plugin.ServicesManager
 */
package com.RkCraft.Stargate;

import com.RkCraft.Stargate.Stargate;
import net.milkbowl.vault.Vault;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Server;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicesManager;

public class iConomyHandler {
    public static boolean useiConomy = false;
    public static Vault vault = null;
    public static Economy economy = null;
    public static int useCost = 0;
    public static int createCost = 0;
    public static int destroyCost = 0;
    public static boolean toOwner = false;
    public static boolean chargeFreeDestination = true;
    public static boolean freeGatesGreen = false;

    public static double getBalance(String player) {
        if (!useiConomy) {
            return 0.0;
        }
        if (economy != null) {
            return economy.getBalance(player);
        }
        return 0.0;
    }

    public static boolean chargePlayer(String player, String target, double amount) {
        if (!useiConomy) {
            return true;
        }
        if (economy != null) {
            if (player.equals(target)) {
                return true;
            }
            if (!economy.has(player, amount)) {
                return false;
            }
            economy.withdrawPlayer(player, amount);
            if (target != null) {
                economy.depositPlayer(target, amount);
            }
            return true;
        }
        return false;
    }

    public static boolean useiConomy() {
        if (!useiConomy) {
            return false;
        }
        return economy != null;
    }

    public static String format(int amt) {
        if (economy != null) {
            return economy.format((double)amt);
        }
        return "";
    }

    public static boolean setupeConomy(PluginManager pm) {
        if (!useiConomy) {
            return false;
        }
        Plugin p = pm.getPlugin("Vault");
        if (p != null) {
            return iConomyHandler.setupVault(p);
        }
        return false;
    }

    public static boolean setupVault(Plugin p) {
        if (!useiConomy) {
            return false;
        }
        if (p == null || !p.isEnabled()) {
            return false;
        }
        if (!p.getDescription().getName().equals("Vault")) {
            return false;
        }
        RegisteredServiceProvider economyProvider = Stargate.server.getServicesManager().getRegistration(Economy.class);
        if (economyProvider != null) {
            vault = (Vault)p;
            economy = (Economy)economyProvider.getProvider();
        }
        return economy != null;
    }

    public static boolean setupRegister(Plugin p) {
        if (!useiConomy) {
            return false;
        }
        if (vault != null) {
            return false;
        }
        return p != null && p.isEnabled();
    }

    public static boolean checkLost(Plugin p) {
        if (p.equals((Object)vault)) {
            economy = null;
            vault = null;
            return true;
        }
        return false;
    }
}

